In the file name, 

DE: differentially expressed gene analysis;

OvRe: over-representation analysis;

sig: significant genes with p-values less than 0.05;

ger.Klo.vs.GFP: differences of treatment in geriatric group, Klotho (treated) vs. GFP (control);

old.Klo.vs.GFP: differences of treatment in old group, Klotho (treated) vs. GFP (control);

young.GFP.vs.Blank: differences of treatment in young group, GFP (treated) vs. blank (control);

gfp.ger.vs.young: differences of age between the geriatric group and young group (baseline) under the treatment of GFP;

gfp.old.vs.young: differences of age between the old group and young group (baseline) under the treatment of GFP;

GO.lvl3: all GO terms enriched in level 3, including GO terms with p-values > 0.05;

KEGG: all KEGG pathways, including KEGG pathways with p-values > 0.05;

SPIA: signaling pathway impact analysis, a specific Gene Set Enrichment Analysis (GSEA) analysis for KEGG pathways enrichment, including KEGG pathways with global p-values (pG) > 0.05.

This fold contains result files from the pipeline of DE analysis and functional enrichment. For functional enrichment, there are two different types. One is over-representation analysis that just focuses on significant DE genes, and use these genes to enrich corresponding biological functions, GO and KEGG. For GO analysis here, the analysis only checked the changes in the "biological process," and if the rest two parts are also interesting, please let me know. Another functional analysis is SPIA, which is employing all genes with expression patterns because some of them may play vital roles in the whole treatment/ aging process, though their changing is small. This analysis also demonstrates whether a pathway is significantly regulated, as well as the regulating status, all of which will contribute to helping complete the storyboard.  